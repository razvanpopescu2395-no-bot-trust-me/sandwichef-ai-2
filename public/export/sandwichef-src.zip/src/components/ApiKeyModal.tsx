import React, { useState } from 'react';
import { KeyRound, X, Check, Trash2, Eye, EyeOff, Sparkles, ShieldCheck } from 'lucide-react';
import { getStoredApiKey, saveApiKey, clearApiKey, getApiKeyStatus } from '../utils/apiKeyManager';
import { Language } from '../types';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, lang }) => {
  const [keyInput, setKeyInput] = useState(getStoredApiKey());
  const [showPassword, setShowPassword] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const status = getApiKeyStatus();

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = keyInput.trim();
    saveApiKey(clean);
    setStatusMessage(
      lang === 'ro'
        ? 'Cheia API a fost salvată cu succes!'
        : lang === 'it'
        ? 'Chiave API salvata con successo!'
        : 'API Key successfully saved!'
    );
    setTimeout(() => {
      setStatusMessage(null);
      onClose();
    }, 1200);
  };

  const handleClear = () => {
    clearApiKey();
    setKeyInput('');
    setStatusMessage(
      lang === 'ro'
        ? 'Cheia a fost ștearsă.'
        : lang === 'it'
        ? 'Chiave rimossa.'
        : 'API Key cleared.'
    );
    setTimeout(() => setStatusMessage(null), 1500);
  };

  return (
    <div
      id="api-key-modal-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
    >
      <div
        id="api-key-modal-content"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#FAF7F2] rounded-3xl p-6 sm:p-7 border border-[#E4D9CA] shadow-2xl relative overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#241813]/10 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#C44E36]/15 text-[#C44E36] flex items-center justify-center shrink-0">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-[#241813]">
                {lang === 'ro' ? 'Configurare Cheie API' : lang === 'it' ? 'Configurazione Chiave API' : 'API Key Settings'}
              </h3>
              <p className="text-xs text-[#6B5E55]">
                {lang === 'ro'
                  ? 'Gestionare conexiune servicii AI & Cloud'
                  : lang === 'it'
                  ? 'Gestione connessione servizi AI & Cloud'
                  : 'Manage AI & Cloud service connection'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#241813]/5 hover:bg-[#241813]/10 flex items-center justify-center text-[#241813] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current status pill */}
        <div className="mb-4 p-3 rounded-2xl bg-white border border-[#E4D9CA] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${
                status.hasKey ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            />
            <span className="font-semibold text-[#241813]">
              {status.hasKey
                ? lang === 'ro'
                  ? `Cheie activă (${status.keySource})`
                  : lang === 'it'
                  ? `Chiave attiva (${status.keySource})`
                  : `Active key (${status.keySource})`
                : lang === 'ro'
                ? 'Nicio cheie configurată (mod local)'
                : lang === 'it'
                ? 'Nessuna chiave (modalità locale)'
                : 'No key configured (local mode)'}
            </span>
          </div>
          {status.hasKey && (
            <span className="font-mono text-[11px] text-[#6B5E55] bg-[#FAF7F2] px-2 py-0.5 rounded-md border border-[#E4D9CA]">
              {status.maskedKey}
            </span>
          )}
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#241813] uppercase tracking-wider mb-1.5">
              {lang === 'ro' ? 'Cheie API personalizată' : lang === 'it' ? 'Chiave API personalizzata' : 'Custom API Key'}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full px-3.5 py-2.5 pr-11 rounded-xl bg-white border border-[#E4D9CA] text-[#241813] placeholder-[#8C7E74]/60 text-sm focus:outline-none focus:border-[#C44E36] focus:ring-1 focus:ring-[#C44E36] transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-[#8C7E74] hover:text-[#241813] transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-[#8C7E74] mt-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>
                {lang === 'ro'
                  ? 'Stocare securizată exclusiv în browserul tău local.'
                  : lang === 'it'
                  ? 'Archiviazione sicura esclusivamente nel tuo browser.'
                  : 'Securely saved in local browser storage only.'}
              </span>
            </div>
          </div>

          {statusMessage && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          <div className="flex items-center gap-2.5 pt-2">
            <button
              type="submit"
              className="flex-1 py-2.5 px-4 rounded-xl bg-[#C44E36] hover:bg-[#A83D28] text-white font-bold text-xs tracking-wide shadow-xs active:scale-98 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{lang === 'ro' ? 'Salvează Cheia' : lang === 'it' ? 'Salva Chiave' : 'Save Key'}</span>
            </button>

            {status.hasKey && (
              <button
                type="button"
                onClick={handleClear}
                className="py-2.5 px-3 rounded-xl bg-[#241813]/5 hover:bg-rose-50 text-[#8C7E74] hover:text-rose-600 border border-[#E4D9CA] font-semibold text-xs transition-all cursor-pointer"
                title="Șterge cheia"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </form>

        {/* Note */}
        <p className="text-[11px] text-[#6B5E55] text-center mt-4">
          {lang === 'ro'
            ? 'Notă: Meniul complet și comenzile WhatsApp funcționează perfect și fără cheie API.'
            : lang === 'it'
            ? 'Nota: Il menu completo e gli ordini WhatsApp funzionano perfettamente anche senza chiave API.'
            : 'Note: Full menu browsing and WhatsApp orders work perfectly without an API key.'}
        </p>
      </div>
    </div>
  );
};
